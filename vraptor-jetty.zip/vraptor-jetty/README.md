# vraptor-jetty

Para startar o Jetty com VRaptor 4 é só rodar a classe Main do projeto e acessar http://localhost:8080
