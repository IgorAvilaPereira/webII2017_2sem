package controller;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Result;
import database.StudentDAO;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;

/**
 * Created by felipeweb on 27/03/15.
 * https://github.com/felipeweb/vraptor-jetty
 */
@Controller
public class IndexController {
    private final Result result;

    /**
     * @deprecated CDI eyes only
     */
    protected IndexController() {
        this(null);
    }

    @Inject
    public IndexController(Result result) {
        this.result = result;
    }

    @Get("/")
    public void index() {
        //try {
            result.include("mensagem", "Funciona!!!");
            //this.result.redirectTo(this).oi();
        /*} catch (SQLException ex) {
            Logger.getLogger(IndexController.class.getName()).log(Level.SEVERE, null, ex);
        }*/
    }
    
    
    @Get("/oi")
    public void oi() throws SQLException {        
        //ArrayList<Student> vet = new ArrayList();
        //vet.add(new Student("Igor"));
        //vet.add(new Student("Homero"));        
        result.include("vet", new StudentDAO().select());
    }   
    
}
