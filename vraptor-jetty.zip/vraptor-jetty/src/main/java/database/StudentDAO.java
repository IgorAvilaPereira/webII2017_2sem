/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Student;

/**
 *
 * @author iapereira
 */
public class StudentDAO {

    public ArrayList<Student> select() throws SQLException {
        Connection c = new ConnectionPostgreSQL().getConnection();
        String sql = "select * from student";
        ResultSet rs = c.prepareStatement(sql).executeQuery();
        ArrayList<Student> studentArray = new ArrayList<>();
        while (rs.next()) {
            studentArray.add(new Student(rs.getString("name")));
        }
        c.close();
        return studentArray;
    }
}
