package controller;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.Result;
import database.StudentDAO;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import model.Student;

/**
 * Created by felipeweb on 27/03/15.
 * https://github.com/felipeweb/vraptor-jetty
 */
@Controller
public class StudentController {
    
    private Result result;
   
     
    /**
     * @deprecated CDI eyes only
     */
    protected StudentController() {
        this(null);
    }

    @Inject
    public StudentController(Result result) {
        this.result = result;
    }
    
    @Get
    @Path("/")
    public void listar() throws SQLException {                    
        result.include("vet", new StudentDAO().select());
    }       
    
    @Get
    @Path("/tela_adicionar")
    public void tela_adicionar(){
        
    }    
    
    @Get
    @Path("/excluir/{id}")
    public void excluir(int id) throws SQLException{
        new StudentDAO().delete(id);
        result.redirectTo(this).listar();        
    }
    
    
    @Get
    @Path("/tela_alterar/{id}")
    public void tela_alterar(int id) throws SQLException{
        result.include("student", new StudentDAO().selectById(id));
    }
    
    @Post
    @Path("/alterar")
    public void alterar(Student student) throws SQLException{
        new StudentDAO().update(student);
        result.redirectTo(this).listar();
    }
    
    @Post
    @Path("/adicionar")
    public void adicionar(Student student) throws SQLException{
        new StudentDAO().insert(student);
        result.redirectTo(this).listar();
    }
}
