/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Student;

/**
 *
 * @author iapereira
 */
public class StudentDAO {

    public ArrayList<Student> select() throws SQLException {
        ArrayList<Student> studentArray;
        try (Connection c = new ConnectionPostgreSQL().getConnection()) {
            String sql = "select * from student";
            ResultSet rs = c.prepareStatement(sql).executeQuery();
            studentArray = new ArrayList<>();
            while (rs.next()) {
                Student student = new Student(rs.getString("name"));
                student.setId(rs.getInt("id"));
                studentArray.add(student);
            }
        }
        return studentArray;
    }

    public void insert(Student student) throws SQLException {
        try (Connection c = new ConnectionPostgreSQL().getConnection()) {
            String sql = "insert into student (name) values (?)";            
            PreparedStatement preparedStatement = c.prepareStatement(sql);
            //preparedStatement.setInt(1, 1);
            preparedStatement.setString(1, student.getName());
            preparedStatement.executeUpdate();
        }
    }
    
       public void delete(int id) throws SQLException {
        try (Connection c = new ConnectionPostgreSQL().getConnection()) {
            String sql = "delete from student where id = ?";            
            PreparedStatement preparedStatement = c.prepareStatement(sql);
            //preparedStatement.setInt(1, 1);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        }
    }

    public Student selectById(int id) throws SQLException {
        Student student = null;
        try (Connection c = new ConnectionPostgreSQL().getConnection()) {
            String sql = "select * from student where id = ?";
            PreparedStatement p = c.prepareStatement(sql);
            p.setInt(1, id);
            ResultSet rs = p.executeQuery();
            if (rs.next()) {
                student = new Student(rs.getString("name"));
                student.setId(rs.getInt("id"));
            }
        }
        return student;
        
    }

    public void update(Student student) throws SQLException {
        try (Connection c = new ConnectionPostgreSQL().getConnection()) {
            String sql = "update student set name = ? where id = ?";            
            PreparedStatement preparedStatement = c.prepareStatement(sql);
            //preparedStatement.setInt(1, 1);
            preparedStatement.setString(1, student.getName());
            preparedStatement.setInt(2, student.getId());
            preparedStatement.executeUpdate();
        }
    }
}
